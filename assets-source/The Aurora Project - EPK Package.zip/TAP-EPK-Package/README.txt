THE AURORA PROJECT — PRESS PACKAGE
Katwijk, NL · est. 1998 · FREIA Music

CONTENTS
  PDF/               Ready-to-send EPK and technical rider (huisstijl v2.0).
  01_Bio/            Long + short bio (EN) and quick facts.
  02_Press-photos/   Colour, black-and-white and halftone band photos.
                     Always credit: Photo: Bert Treep.
  03_Logos/          Wordmark + sun symbol, light-on-dark and dark-on-light.
  04_Discography/    Album covers, full discography and EVOS12 tracklist.
  05_Links/          Official, music, video and press links.

CONTACT — BOOKING & PRESS
  contact.theauroraproject@gmail.com
  +31 6 24 20 39 48 — Remco van den Berg
  theauroraproject.com
